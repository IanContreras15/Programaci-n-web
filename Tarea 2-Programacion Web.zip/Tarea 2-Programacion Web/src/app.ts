import dotenv from 'dotenv';
import { Server } from './servidor';

dotenv.config();

const servidor = new Server();
servidor.listen();