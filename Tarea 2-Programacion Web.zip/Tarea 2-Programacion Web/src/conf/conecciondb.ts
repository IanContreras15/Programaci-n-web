import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
  host: process.env.BD_HOST || 'localhost',
  user: process.env.BD_USUARIO || 'root',
  password: process.env.BD_CLAVE || '',
  database: process.env.BD_NOMBRE || 'tienda_db',
  port: Number(process.env.BD_PUERTO) || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

export default pool;