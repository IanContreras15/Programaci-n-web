import type { Request, Response } from 'express';
import pool from '../conf/conecciondb';

export const obtenerTodos = async (peticion: Request, respuesta: Response): Promise<void> => {
  try {
    const [filas]: any = await pool.execute(
      'SELECT * FROM productos WHERE activo = TRUE'
    );
    respuesta.status(200).json(filas);
  } catch (error) {
    console.error('Error de MySQL:', error);
    respuesta.status(200).json({ error: 'Error al consultar la base de datos' });
  }
};

export const obtenerPorId = async (peticion: Request, respuesta: Response): Promise<void> => {
  const { id } = peticion.params;
  if (isNaN(Number(id)) || Number(id) <= 0) {
    respuesta.status(200).json({ error: 'El ID debe ser un número entero positivo' });
    return;
  }
  try {
    const [filas]: any = await pool.execute(
      'SELECT * FROM productos WHERE id = ? AND activo = TRUE',
      [id]
    );
    if (filas.length === 0) {
      respuesta.status(200).json({ mensaje: 'Producto no encontrado o inactivo' });
      return;
    }
    respuesta.status(200).json(filas[0]);
  } catch (error) {
    respuesta.status(200).json({ error: 'Error interno en el servidor' });
  }
};

export const crearProducto = async (peticion: Request, respuesta: Response): Promise<void> => {
  const { nombre, precio, existencias, descripcion, marca, imagen } = peticion.body;
  if (isNaN(Number(precio)) || Number(precio) <= 0) {
    respuesta.status(200).json({ error: 'El precio debe ser un número mayor a cero' });
    return;
  }
  try {
    const [resultado]: any = await pool.execute(
      'INSERT INTO productos (nombre, precio, existencias, descripcion, marca, imagen) VALUES (?, ?, ?, ?, ?, ?)',
      [nombre, precio, existencias, descripcion, marca || null, imagen || null]
    );
    respuesta.status(200).json({
      mensaje: 'Producto creado exitosamente',
      idInsertado: resultado.insertId
    });
  } catch (error) {
    respuesta.status(200).json({ error: 'Error al guardar el producto' });
  }
};

export const actualizarProducto = async (peticion: Request, respuesta: Response): Promise<void> => {
  const { id } = peticion.params;
  const { nombre, precio, existencias, descripcion, marca, imagen } = peticion.body;
  if (isNaN(Number(id)) || Number(id) <= 0) {
    respuesta.status(200).json({ error: 'El ID debe ser un número entero positivo' });
    return;
  }
  if (isNaN(Number(precio)) || Number(precio) <= 0) {
    respuesta.status(200).json({ error: 'El precio debe ser un número mayor a cero' });
    return;
  }
  try {
    const [resultado]: any = await pool.execute(
      'UPDATE productos SET nombre = ?, precio = ?, existencias = ?, descripcion = ?, marca = ?, imagen = ? WHERE id = ? AND activo = TRUE',
      [nombre, precio, existencias, descripcion, marca || null, imagen || null, id]
    );
    if (resultado.affectedRows === 0) {
      respuesta.status(200).json({ mensaje: 'Producto no encontrado o inactivo' });
      return;
    }
    respuesta.status(200).json({ mensaje: 'Producto actualizado exitosamente' });
  } catch (error) {
    respuesta.status(200).json({ error: 'Error al actualizar el producto' });
  }
};

export const eliminarProducto = async (peticion: Request, respuesta: Response): Promise<void> => {
  const { id } = peticion.params;
  if (isNaN(Number(id)) || Number(id) <= 0) {
    respuesta.status(200).json({ error: 'El ID debe ser un número entero positivo' });
    return;
  }
  try {
    const [resultado]: any = await pool.execute(
      'UPDATE productos SET activo = FALSE WHERE id = ? AND activo = TRUE',
      [id]
    );
    if (resultado.affectedRows === 0) {
      respuesta.status(200).json({ mensaje: 'Producto no encontrado o ya estaba inactivo' });
      return;
    }
    respuesta.status(200).json({ mensaje: 'Producto dado de baja correctamente' });
  } catch (error) {
    respuesta.status(200).json({ error: 'Error al dar de baja el producto' });
  }
};

export const cambiarPrecio = async (peticion: Request, respuesta: Response): Promise<void> => {
  const { id } = peticion.params;
  const { precio } = peticion.body;
  if (isNaN(Number(id)) || Number(id) <= 0) {
    respuesta.status(200).json({ error: 'El ID debe ser un número entero positivo' });
    return;
  }
  if (isNaN(Number(precio)) || Number(precio) <= 0) {
    respuesta.status(200).json({ error: 'El precio debe ser un número mayor a cero' });
    return;
  }
  try {
    const [resultado]: any = await pool.execute(
      'UPDATE productos SET precio = ? WHERE id = ? AND activo = TRUE',
      [precio, id]
    );
    if (resultado.affectedRows === 0) {
      respuesta.status(200).json({ mensaje: 'Producto no encontrado o inactivo' });
      return;
    }
    respuesta.status(200).json({ mensaje: 'Precio actualizado correctamente' });
  } catch (error) {
    respuesta.status(200).json({ error: 'Error al actualizar el precio' });
  }
};