import { Router } from 'express';
import productosRutas from './rutas';

const router = Router();

router.use('/api/v1/products', productosRutas);

export default router;