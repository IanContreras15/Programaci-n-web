import { Router } from 'express';
import {
  obtenerTodos,
  obtenerPorId,
  crearProducto,
  actualizarProducto,
  eliminarProducto,
  cambiarPrecio
} from '../controllers/controlador';

const router = Router();

router.get('/', obtenerTodos);
router.get('/getById/:id', obtenerPorId);
router.post('/create', crearProducto);
router.put('/update/:id', actualizarProducto);
router.delete('/delete/:id', eliminarProducto);
router.patch('/change-price/:id', cambiarPrecio);

export default router;