import express, { Application } from 'express';
import rutasPrincipales from './routes';

export class Server {
  private app: Application;
  private puerto: string | number;

  constructor() {
    this.app = express();
    this.puerto = process.env.PUERTO || 3000;

    this.middlewares();
    this.routes();
  }

  private middlewares(): void {
    // Permite que el servidor entienda peticiones con formato JSON
    this.app.use(express.json());
  }

  private routes(): void {
    // Conecta las rutas de tu API con la aplicación
    this.app.use(rutasPrincipales);
  }

  public listen(): void {
    this.app.listen(this.puerto, () => {
      console.log(`Servidor corriendo en el puerto ${this.puerto}`);
    });
  }
}